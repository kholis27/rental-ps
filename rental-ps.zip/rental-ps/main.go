package main

import (
	"rental-ps/controllers"
	"rental-ps/models"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	models.ConnectDatabase()

	r.Static("/static", "./static")
	r.LoadHTMLGlob("templates/*")

	r.GET("/", controllers.Index)
	r.GET("/rentals", controllers.GetRentals)
	r.POST("/rentals", controllers.CreateRental)
	r.GET("/rentals/edit/:id", controllers.EditRental)
	r.POST("/rentals/update/:id", controllers.UpdateRental)
	r.GET("/rentals/delete/:id", controllers.DeleteRental)
	r.GET("/rentals/export/pdf", controllers.ExportPDF)
	r.GET("/rentals/export/excel", controllers.ExportExcel)

	r.Run(":8080")
}
