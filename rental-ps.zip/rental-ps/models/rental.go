package models

import (
	"time"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var DB *gorm.DB

func ConnectDatabase() {
	database, err := gorm.Open(sqlite.Open("rental.db"), &gorm.Config{})
	if err != nil {
		panic("Failed to connect to database!")
	}

	database.AutoMigrate(&Rental{})

	DB = database
}

type Rental struct {
	ID           uint      `json:"id" gorm:"primary_key"`
	NamaPenyewa  string    `json:"nama_penyewa"`
	TanggalPinjam time.Time `json:"tanggal_pinjam"`
	TanggalKembali time.Time `json:"tanggal_kembali"`
	JenisPS      string    `json:"jenis_ps"`
	HargaSewa    int       `json:"harga_sewa"`
	TotalJam     int       `json:"total_jam"`
	TotalBayar   int       `json:"total_bayar"`
}
