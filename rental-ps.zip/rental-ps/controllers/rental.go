package controllers

import (
	"net/http"
	"rental-ps/models"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/jung-kurt/gofpdf"
	"github.com/xuri/excelize/v2"
)

func Index(c *gin.Context) {
	c.HTML(http.StatusOK, "index.html", nil)
}

func GetRentals(c *gin.Context) {
	var rentals []models.Rental
	models.DB.Find(&rentals)

	c.HTML(http.StatusOK, "rentals.html", gin.H{
		"rentals": rentals,
	})
}

func CreateRental(c *gin.Context) {
	hargaSewa, _ := strconv.Atoi(c.PostForm("harga_sewa"))
	totalJam, _ := strconv.Atoi(c.PostForm("total_jam"))
	tanggalPinjam, _ := time.Parse("2006-01-02", c.PostForm("tanggal_pinjam"))
	tanggalKembali, _ := time.Parse("2006-01-02", c.PostForm("tanggal_kembali"))

	rental := models.Rental{
		NamaPenyewa:  c.PostForm("nama_penyewa"),
		TanggalPinjam: tanggalPinjam,
		TanggalKembali: tanggalKembali,
		JenisPS:      c.PostForm("jenis_ps"),
		HargaSewa:    hargaSewa,
		TotalJam:     totalJam,
		TotalBayar:   hargaSewa * totalJam,
	}

	models.DB.Create(&rental)

	c.Redirect(http.StatusFound, "/rentals")
}

func EditRental(c *gin.Context) {
	var rental models.Rental
	id := c.Param("id")

	if err := models.DB.First(&rental, id).Error; err != nil {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}

	c.HTML(http.StatusOK, "edit.html", gin.H{
		"rental": rental,
	})
}

func UpdateRental(c *gin.Context) {
	var rental models.Rental
	id := c.Param("id")

	if err := models.DB.First(&rental, id).Error; err != nil {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}

	hargaSewa, _ := strconv.Atoi(c.PostForm("harga_sewa"))
	totalJam, _ := strconv.Atoi(c.PostForm("total_jam"))
	tanggalPinjam, _ := time.Parse("2006-01-02", c.PostForm("tanggal_pinjam"))
	tanggalKembali, _ := time.Parse("2006-01-02", c.PostForm("tanggal_kembali"))

	rental.NamaPenyewa = c.PostForm("nama_penyewa")
	rental.TanggalPinjam = tanggalPinjam
	rental.TanggalKembali = tanggalKembali
	rental.JenisPS = c.PostForm("jenis_ps")
	rental.HargaSewa = hargaSewa
	rental.TotalJam = totalJam
	rental.TotalBayar = hargaSewa * totalJam

	models.DB.Save(&rental)

	c.Redirect(http.StatusFound, "/rentals")
}

func DeleteRental(c *gin.Context) {
	var rental models.Rental
	id := c.Param("id")

	if err := models.DB.First(&rental, id).Error; err != nil {
		c.AbortWithStatus(http.StatusNotFound)
		return
	}

	models.DB.Delete(&rental)

	c.Redirect(http.StatusFound, "/rentals")
}

func ExportPDF(c *gin.Context) {
	var rentals []models.Rental
	models.DB.Find(&rentals)

	pdf := gofpdf.New("P", "mm", "A4", "")
	pdf.AddPage()
	pdf.SetFont("Arial", "B", 16)
	pdf.Cell(40, 10, "Data Rental PS")
	pdf.Ln(12)

	pdf.SetFont("Arial", "B", 12)
	pdf.Cell(10, 10, "ID")
	pdf.Cell(40, 10, "Nama Penyewa")
	pdf.Cell(35, 10, "Tanggal Pinjam")
	pdf.Cell(35, 10, "Tanggal Kembali")
	pdf.Cell(20, 10, "Jenis PS")
	pdf.Cell(25, 10, "Harga/Jam")
	pdf.Cell(20, 10, "Total Jam")
	pdf.Cell(25, 10, "Total Bayar")
	pdf.Ln(10)

	pdf.SetFont("Arial", "", 12)
	for _, rental := range rentals {
		pdf.Cell(10, 10, strconv.Itoa(int(rental.ID)))
		pdf.Cell(40, 10, rental.NamaPenyewa)
		pdf.Cell(35, 10, rental.TanggalPinjam.Format("2006-01-02"))
		pdf.Cell(35, 10, rental.TanggalKembali.Format("2006-01-02"))
		pdf.Cell(20, 10, rental.JenisPS)
		pdf.Cell(25, 10, strconv.Itoa(rental.HargaSewa))
		pdf.Cell(20, 10, strconv.Itoa(rental.TotalJam))
		pdf.Cell(25, 10, strconv.Itoa(rental.TotalBayar))
		pdf.Ln(10)
	}

	c.Writer.Header().Set("Content-Type", "application/pdf")
	c.Writer.Header().Set("Content-Disposition", `attachment; filename="rentals.pdf"`)
	err := pdf.Output(c.Writer)
	if err != nil {
		c.AbortWithStatus(http.StatusInternalServerError)
	}
}

func ExportExcel(c *gin.Context) {
	var rentals []models.Rental
	models.DB.Find(&rentals)

	f := excelize.NewFile()
	// Create a new sheet.
	index, _ := f.NewSheet("Sheet1")
	// Set value of a cell.
	f.SetCellValue("Sheet1", "A1", "ID")
	f.SetCellValue("Sheet1", "B1", "Nama Penyewa")
	f.SetCellValue("Sheet1", "C1", "Tanggal Pinjam")
	f.SetCellValue("Sheet1", "D1", "Tanggal Kembali")
	f.SetCellValue("Sheet1", "E1", "Jenis PS")
	f.SetCellValue("Sheet1", "F1", "Harga/Jam")
	f.SetCellValue("Sheet1", "G1", "Total Jam")
	f.SetCellValue("Sheet1", "H1", "Total Bayar")

	for i, rental := range rentals {
		row := i + 2
		f.SetCellValue("Sheet1", "A"+strconv.Itoa(row), rental.ID)
		f.SetCellValue("Sheet1", "B"+strconv.Itoa(row), rental.NamaPenyewa)
		f.SetCellValue("Sheet1", "C"+strconv.Itoa(row), rental.TanggalPinjam.Format("2006-01-02"))
		f.SetCellValue("Sheet1", "D"+strconv.Itoa(row), rental.TanggalKembali.Format("2006-01-02"))
		f.SetCellValue("Sheet1", "E"+strconv.Itoa(row), rental.JenisPS)
		f.SetCellValue("Sheet1", "F"+strconv.Itoa(row), rental.HargaSewa)
		f.SetCellValue("Sheet1", "G"+strconv.Itoa(row), rental.TotalJam)
		f.SetCellValue("Sheet1", "H"+strconv.Itoa(row), rental.TotalBayar)
	}

	// Set active sheet of the workbook.
	f.SetActiveSheet(index)

	c.Writer.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Writer.Header().Set("Content-Disposition", `attachment; filename="rentals.xlsx"`)
	if err := f.Write(c.Writer); err != nil {
		c.AbortWithStatus(http.StatusInternalServerError)
	}
}
